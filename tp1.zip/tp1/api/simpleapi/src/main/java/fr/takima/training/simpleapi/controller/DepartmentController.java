package fr.takima.training.simpleapi.controller;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/departments")
public class DepartmentController {
    
    @GetMapping("/{dept}/students")
    public List<Map<String, Object>> getStudentsByDepartment(@PathVariable String dept) {
        return List.of(
            Map.of(
                "id", 1,
                "firstname", "Eli",
                "lastname", "Copter",
                "department", Map.of("id", 1, "name", dept)
            )
        );
    }
    
    @GetMapping
    public List<Map<String, Object>> getAllDepartments() {
        return List.of(
            Map.of("id", 1, "name", "IRC"),
            Map.of("id", 2, "name", "GC")
        );
    }
}
